<?php
// Needed for isolated tests
require __DIR__ . '/../vendor/autoload.php';

ini_set('precision', 14);
ini_set('serialize_precision', 14);
